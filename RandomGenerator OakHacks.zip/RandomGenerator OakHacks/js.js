

function generateNumber() {
	
	var min = document.getElementById("minvalue").value;
	var max = document.getElementById("maxvalue").value;  
	if(min != 0 && max != 0) {
		var temp = Math.round(Math.random() * (max - min) + min);

		if(temp < min)
			temp = min
		if(temp > max)
			temp = max

		var ranNum = temp.toString();
		document.getElementById("numAnswer").innerHTML = `Your Random Number Is: ${ranNum} `;

	}
	else {
		alert("Error: Please Enter A Minimum And Maximum Value")
	}
	
}

function randomLetter() {
	var letters = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
	var ranLeter = letters[Math.floor(Math.random() * letters.length)]
	document.getElementById("letterAnswer").innerHTML = `Your Random Letter Is: ${ranLeter} `;
}

function ScrollTo(name) {
  ScrollToResolver(document.getElementById(name));
}

function ScrollToResolver(elem) {
	
  if(elem === 'numberSection')
	 window. scrollTo(0, 0)
  var jump = parseInt(elem.getBoundingClientRect().top * .2);
  document.body.scrollTop += jump;
  document.documentElement.scrollTop += jump;
  if (!elem.lastjump || elem.lastjump > Math.abs(jump)) {
    elem.lastjump = Math.abs(jump);
    setTimeout(function() { ScrollToResolver(elem);}, "30");
  } else {
    elem.lastjump = null;
  }
}

function openBurger() {
  var element = document.getElementByClassName("headertext2");
  element.classList.toggle("mystyle")
  }

function flipCoin() {
	var coin = ["heads", "tails"]
	var coinFliped = coin[Math.floor(Math.random() * coin.length)]
	document.getElementById("coinGenAnswer").innerHTML = `The coin landed on: ${coinFliped} `;
}

function rollDice() 
{
	
	var diceSides = document.getElementById("dicevalue").value;
	var diceAmount = document.getElementById("dice1value").value;
	if(diceAmount >= 10)
		return alert("Please Enter A Lower Dice Amount");
	if(diceAmount <= 0)
		return alert("Please Enter A Valid Dice Amount")
	var diceAnswers = new Array();
	for(var i = 0; i < diceAmount; i++) 
	{
		diceAnswers[i] = " " + (Math.floor(Math.random() * diceSides) + 1) ;
	}
		document.getElementById("diceGenAnswer").innerHTML = `You rolled a: ${diceAnswers}!`;
	
 }	

	


/*
	
	
	
	


		*/